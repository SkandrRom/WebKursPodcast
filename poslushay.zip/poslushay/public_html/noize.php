﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Разговоры</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/nase.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/vendor.css">

    <link rel="shortcut icon" href="favicon.png" type="image/x-icon">
    <link rel="icon" href="favicon.png" type="image/x-icon">

    <?php require_once "connect.php"; ?>

    <script src="js/modernizr.js"></script>
    <script src="js/pace.min.js"></script>
</head>
<body id="top">

<header class="s-header">

    <div class="row">

        <div class="header-logo">

        </div>

        <nav class="header-nav-wrap">
            <ul class="header-nav">
                <li ><a href="index.html">ПС</a></li>
                <li class="current"><a  href="noize.php" title="Слушай">Разговоры</a></li>
                <li><a  href="pro.php" title="Отдел про">PRO</a></li>
                <li><a  href="mat.php" title="Материалы">Мат</a></li>
            </ul>
        </nav> <!-- end header-nav-wrap -->
            <a class="header-menu-toggle" href="#0">
            <span class="header-menu-icon"></span>
            </a>
</div> <!-- end row -->
</header> <!-- end s-header -->

<section id="home" class="s-home page-hero" data-parallax="scroll"  data-position-y=center  >
<div class="row services-list block-1 block-m-1-2 block-tab-full">
<div class="push">
    <?php
           $lan = getPodcast();
           foreach($lan as $la)

           :?>
    <div class="col-block item-process" data-aos="fade-up">
        <div class="item-process__header item-process__header--implementation">
            <div><iframe width="250" height="150" src="<?php echo $la["link"]; ?>" title="YouTube video player" frameborder="0" allow="accelerometer;
                          autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>
            <h3><?php echo $la["title"]; ?></h3>
            <p><?php echo $string = substr($la["text"], 0, 283); ?>... </p>
        </div>
    </div>
    <?php endforeach; ?>


</div>
</div>
</section>

<section id="about" class="s-about target-section">

    <div class="row section-header" data-aos="fade-up">
        <div class="col-full">
            <h1 >
             А все, больше у меня ничего нет!
            </h1>

        </div>
    </div>



</section> <!-- end s-about -->

<footer>
    <div class="fotter-content__scrolls">
        <a class="smoothscroll" href="#top" >
            Вверх
        </a>
    </div>
</footer>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/plugins.js"></script>
<script src="js/main.js"></script>
</body>
</html>