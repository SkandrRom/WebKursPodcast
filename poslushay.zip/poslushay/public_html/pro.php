<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PRO</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/nase.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/vendor.css">

    <link rel="shortcut icon" href="favicon.png" type="image/x-icon">
    <link rel="icon" href="favicon.png" type="image/x-icon">


    <script src="js/modernizr.js"></script>
    <script src="js/pace.min.js"></script>

</head>
<body class="top">
<header class="s-header">

    <div class="row">

        <div class="header-logo">

        </div>

        <nav class="header-nav-wrap">
            <ul class="header-nav">
                <li ><a href="index.html" >ПС</a></li>
                <li><a  href="noize.php" title="Слушай">Разговоры</a></li>
                <li class="current"><a  href="pro.php" title="Отдел про">PRO</a></li>
                <li><a  href="mat.php" title="Материалы">Мат</a></li>
            </ul>
        </nav> <!-- end header-nav-wrap -->

        <a class="header-menu-toggle" href="#0">
            <span class="header-menu-icon"></span>
        </a>

    </div> <!-- end row -->

</header> <!-- end s-header -->

<section class="s-about">
    <div class="row load">
        <div class="push">
            <div class="output">
                <form id="mc-form" class="group mc-form">
                    <input type="text" value="" name="passw" class="password" placeholder="Волшебное слово" autocomplete="off" >
                </form>
                <form class="group mc-form">
                    <input type="button" name="welcome" value="Вход" onClick='location.href="proW.php"'>
                    </input>
                </form>
            </div>
        </div>
    </div>
</section>
<!--<footer>-->
<!--    <div class="fotter-content__scrolls">-->
<!--        <a class="smoothscroll" href="#top" >-->
<!--            Вверх-->
<!--        </a>-->
<!--    </div>-->
<!--</footer>-->

<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/plugins.js"></script>
<script src="js/main.js"></script>
</body>

</html>