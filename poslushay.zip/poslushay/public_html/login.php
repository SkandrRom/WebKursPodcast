<?php
require_once 'connect.php';

function getPassw(){
global $db;
$pro = $db->query("SELECT * FROM pro");
return $pro;
}

$pro = $_POST['passw'];
$check_user = mysqli_query($connect, "SELECT * FROM 'pro' WHERE 'passw' = '$passw'");
if(mysqli_num_rows($check_user)>0){
$user = mysqli_fetch_assoc($check_user);

$_SESSION['pro'] = ["passw" => $pro['passw']];

header('Location: index.html');
}
else{
header('Location: mat.php');
}

?>