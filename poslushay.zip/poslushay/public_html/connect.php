<?php
$dbhost = "localhost";
$dbname = "ca81013_past";
$username = "ca81013_past";
$password = "1romRoot32";

$db = new PDO("mysql:host=$dbhost; dbname=$dbname",$username,$password);

function pastDB(){
global $db;
$articles = $db->query("SELECT * FROM articles");
return $articles;
}

function getPodcast(){
global $db;
$lan = $db->query("SELECT * FROM lan");
return $lan;
}

function getPRO(){
global $db;
$prow = $db->query("SELECT * FROM prow");
return $prow;
}

function getID($id){
global $db;
$articles = $db->query("SELECT * FROM articles WHERE id = $id");

if (is_array($articles) || is_object($articles))
{
    foreach ($articles as $article)
    {
        return $article;
    }
}
}
?>
